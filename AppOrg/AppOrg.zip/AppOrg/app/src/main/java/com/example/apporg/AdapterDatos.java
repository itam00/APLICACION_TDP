package com.example.apporg;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {
    ArrayList<Evento> listDatos;


    public AdapterDatos(ArrayList<Evento> lista) {
        listDatos = lista;
    }


    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,null,false);
        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos holder, int position) {
        holder.asignarDatos(listDatos.get(position));
    }

    @Override
    public int getItemCount() {
        return listDatos.size();
    }
    public class ViewHolderDatos extends RecyclerView.ViewHolder {
        TextView tvNombreEvento,tvDescripcionEvento,tvHoraDesde,tvHoraHasta;
        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            tvNombreEvento = itemView.findViewById(R.id.textView_nombre_evento);
            tvDescripcionEvento = itemView.findViewById(R.id.textView_descripcion_evento);
            tvHoraDesde = itemView.findViewById(R.id.textView_hora_desde_evento);
            tvHoraHasta = itemView.findViewById(R.id.textView_hora_hasta_evento);

        }
        public void asignarDatos(Evento evento) {
            tvNombreEvento.setText(evento.getNombre());
            tvDescripcionEvento.setText(evento.getDescripcion());
            tvHoraDesde.setText(evento.getHoraDesde());
            tvHoraHasta.setText(evento.getHoraHasta());
        }
    }
}
