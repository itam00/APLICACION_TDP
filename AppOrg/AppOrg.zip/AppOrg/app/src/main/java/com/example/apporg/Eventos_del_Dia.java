package com.example.apporg;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Rect;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Eventos_del_Dia extends AppCompatActivity {
    protected ArrayList<Evento> listDatos;
    protected RecyclerView recycler;
    protected int dia,mes,anio;
    protected Bundle extras;
    protected BDSQLite conn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventos_del__dia);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        extras = getIntent().getExtras();
        dia= extras.getInt("dia");
        mes= extras.getInt("mes");
        anio= extras.getInt("anio");

        getSupportActionBar().setTitle(dia+"/"+mes+"/"+anio);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        recycler= findViewById(R.id.recyclerId);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.addItemDecoration(new VerticalSpaceItemDecoration(10));
        listDatos = new ArrayList<>();

        cargarEventos();


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplication(), Agregar_Evento_Activity.class);
                intent.putExtra("dia",dia);
                intent.putExtra("mes",mes);
                intent.putExtra("anio",anio);
                startActivity(intent);
            }
        });


    }


    public void cargarEventos(){
        conn = new BDSQLite(getApplication(),"bd_eventos",null,1);
        SQLiteDatabase db = conn.getReadableDatabase();

        String[] parametros= {dia+""+""+mes+""+anio};
        String[] campos= {Utilidades.CAMPO_NOMBRE,Utilidades.CAMPO_DESCRIPCION,Utilidades.CAMPO_HORADESDE,Utilidades.CAMPO_HORAHASTA};

        Cursor cursor = db.query(Utilidades.TABLA_EVENTOS,campos,Utilidades.CAMPO_FECHA+"=?",parametros,null,null,null);

        if(cursor.moveToFirst()) {

            do {
                Evento evento = new Evento();
                evento.setNombre(cursor.getString(0));
                evento.setDescripcion(cursor.getString(1));
                evento.setHoraDesde(cursor.getString(2));
                evento.setHoraHasta(cursor.getString(3));
                listDatos.add(evento);
            } while (cursor.moveToNext());

            AdapterDatos adaptador = new AdapterDatos(listDatos);
            recycler.setAdapter(adaptador);
        }
        else{
            Toast.makeText(getApplication(), parametros[0], Toast.LENGTH_SHORT).show();
        }



    }

    public class VerticalSpaceItemDecoration extends RecyclerView.ItemDecoration {

        private final int verticalSpaceHeight;

        public VerticalSpaceItemDecoration(int verticalSpaceHeight) {
            this.verticalSpaceHeight = verticalSpaceHeight;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent,
                                   RecyclerView.State state) {
            outRect.bottom = verticalSpaceHeight;
        }
    }
}
