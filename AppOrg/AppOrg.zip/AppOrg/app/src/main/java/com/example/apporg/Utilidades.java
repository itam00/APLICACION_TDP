package com.example.apporg;

public class Utilidades {
    public static final String TABLA_EVENTOS= "eventos";
    public static final String CAMPO_NOMBRE= "nombre";
    public static final String CAMPO_DESCRIPCION= "descripcion";
    public static final String CAMPO_FECHA= "fecha";
    public static final String CAMPO_HORADESDE= "horaDesde";
    public static final String CAMPO_HORAHASTA= "horaHasta";



    public static final String CREAR_TABLA_USUARIO = "CREATE TABLE "+TABLA_EVENTOS+
            "("+CAMPO_NOMBRE+" TEXT, "+
            CAMPO_DESCRIPCION+" TEXT, "+
            CAMPO_FECHA+" TEXT, "+
            CAMPO_HORADESDE+" TEXT, "+
            CAMPO_HORAHASTA+" TEXT)";

}
