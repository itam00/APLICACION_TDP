package com.example.apporg;

import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Agregar_Evento_Activity extends AppCompatActivity {

    protected EditText etHoraDesde,etHoraHasta,etNombreEvento,etDescripcionEvento;
    protected ImageButton ibFechaDesde,ibFechaHasta;
    protected Button btAgregar,btCancelar;
    protected int dia,mes,anio;
    protected Bundle extras;
    protected Intent volverIntent;

    public final Calendar c = Calendar.getInstance();

    final int hora = c.get(Calendar.HOUR_OF_DAY);
    final int minuto = c.get(Calendar.MINUTE);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_evento);

        volverIntent  = new Intent(getApplication(),Eventos_del_Dia.class);
        extras = getIntent().getExtras();
        dia = extras.getInt("dia");
        mes = extras.getInt("mes");
        anio = extras.getInt("anio");
        volverIntent.putExtra("dia",dia);
        volverIntent.putExtra("mes",mes);
        volverIntent.putExtra("anio",anio);

        etNombreEvento = findViewById(R.id.editText_nombre_evento);
        etDescripcionEvento = findViewById(R.id.editText_descripcion_evento);
        etHoraDesde = findViewById(R.id.editText_hora_desde);
        etHoraHasta = findViewById(R.id.editText_hora_hasta);



        configurarBotonesFecha();
        configurarBotonCancelar();
        configurarBotonGuardar();

    }

    public void configurarBotonCancelar(){
        btCancelar = findViewById(R.id.button_cancelar_evento);
        btCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(volverIntent);
            }
        });
    }

    public void configurarBotonGuardar(){
        btAgregar = findViewById(R.id.button_guardar_evento);
        btAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String nombre,descripcion,horaDesde,horaHasta;
                nombre=etNombreEvento.getText().toString();
                descripcion = etDescripcionEvento.getText().toString();
                horaDesde = etHoraDesde.getText().toString();
                horaHasta = etHoraHasta.getText().toString();

                BDSQLite conn = new BDSQLite(getApplication(),"bd_eventos",null,1);
                SQLiteDatabase db = conn.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put(Utilidades.CAMPO_NOMBRE,nombre);
                values.put(Utilidades.CAMPO_DESCRIPCION,descripcion);
                values.put(Utilidades.CAMPO_HORADESDE,horaDesde);
                values.put(Utilidades.CAMPO_HORAHASTA, horaHasta);
                values.put(Utilidades.CAMPO_FECHA,dia+""+""+mes+""+anio);

                Long idResultante = db.insert(Utilidades.TABLA_EVENTOS,Utilidades.CAMPO_NOMBRE,values);
                Toast.makeText(getApplication(), ""+idResultante, Toast.LENGTH_SHORT).show();

                startActivity(volverIntent);

            }
        });

    }

    public void configurarBotonesFecha(){
        ibFechaDesde = findViewById(R.id.imageButton_hora_desde);
        ibFechaHasta = findViewById(R.id.imageButton_hora_hasta);
        ibFechaDesde.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                obtenerHora(etHoraDesde);
            }
        });
        ibFechaHasta.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                obtenerHora(etHoraHasta);
            }
        });
    }

    private void obtenerHora(final EditText etHora){
        TimePickerDialog recogerHora = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            EditText hora=etHora;
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                //Formateo el hora obtenido: antepone el 0 si son menores de 10
                String horaFormateada =  (hourOfDay < 10)? String.valueOf("0" + hourOfDay) : String.valueOf(hourOfDay);
                //Formateo el minuto obtenido: antepone el 0 si son menores de 10
                String minutoFormateado = (minute < 10)? String.valueOf("0" + minute):String.valueOf(minute);
                //Obtengo el valor a.m. o p.m., dependiendo de la selección del usuario
                String AM_PM;
                if(hourOfDay < 12) {
                    AM_PM = "a.m.";
                } else {
                    AM_PM = "p.m.";
                }
                //Muestro la hora con el formato deseado
                hora.setText(horaFormateada + ":" + minutoFormateado + " " + AM_PM);
            }
            //Estos valores deben ir en ese orden
            //Al colocar en false se muestra en formato 12 horas y true en formato 24 horas
            //Pero el sistema devuelve la hora en formato 24 horas
        }, hora, minuto, false);

        recogerHora.show();
    }
}
